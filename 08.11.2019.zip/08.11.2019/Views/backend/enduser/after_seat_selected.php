<!-- verification and payment proceeding page
    //* editor:G.Vishnu Vardhan
    //* date : 06.11.2019
    //* description : design the preview the ticket details and confirm the details.Then payment page designed in a single page that is trigered by javascript and jquery
 -->

<!DOCTYPE html>
<html>
<head>
  <!-- library file included this file css,bootstrap,javascript -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../../Assets/backend/seat_css/sidebar/style.css">
  <link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.css">
  <link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.min.css">
  <link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.css">
  <script type="text/javascript" src="../../../Assets/backend/seat_js/jquery.js"></script>
  <script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.js"></script>
  <script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.min.js"></script>
</head>
<body>
  <!-- main-container -->
  <div class="container-fluid">
    <!-- sidebar-container -->
    <div class="sidenav">
      <a class="active" href="#Credit Card">Credit Card/Debit card</a>
      <a href="#Online Banking">Online Banking</a>
      <a href="#Other Payment Options">Other Payment Options</a>
    </div>
    <!-- sidebar-container end -->
    <!-- payment page -->
    <div class="main payment" id="payment">
      <!-- Credit card / Debit card form -->
      <form action="http://localhost/files/php/Movie_Ticket_Booking-01.11.19--master/Test%20Folder/something.php">
        <div class="row">
          <h3 class="text-center">Enter your Card details</h3><br>
          <div class="col-md-12">
            <div class="col-md-3"></div>
            <div class="col-md-6 card-body">
              <div class="col-md-12 card-content">
                <div class="col-md-6">
                  <label>Card Number:</label>
                </div>
                <div class="col-md-6">
                  <input type="text" id="cardNumber" name="cardNumbar" placeholder="XXXX XXXX XXXX XXXX">
                </div>
              </div>

              <div class="col-md-12 card-content">
                <div class="col-md-6">
                  <label>Name on the card:</label>
                </div>
                <div class="col-md-6">
                  <input type="name" id="cardHolder" name="cardHolder" placeholder="ex...sundar">
                </div>
              </div>

              <div class="col-md-12 card-content">
                <div class="col-md-6">
                  <label>Expiry Date:</label>
                </div>
                <div class="col-md-3">
                  <input type="Number" id="ExpiryMonth" name="ExpiryDate" placeholder="MM" max="12" min="1" autocomplete="cc-exp-month">
                </div>
                <div class="col-md-3">
                  <input type="Number" id="ExpiryYear" name="ExpiryYear" placeholder="MM" min="2020" max="2060" autocomplete="cc-exp-month">
                </div>
              </div>

              <div class="col-md-12 text-center card-center">
                <input type="submit" class="submit" onclick="paymentSubmission();" name="paymentSubmit">
              </div>
            </div>
            <div class="col-md-3"></div>
          </div>
        </div>
      </form>
      <!-- Credit card / Debit card form end -->
    </div>
  <!-- preview confirmation page -->
  <div class="main confirmation" id="confirmation">
    <!-- payment form -->
    <form action="#payment">
      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6 card-body">
          <h3 class="text-center">Confirm the details</h3>
          <div class="row">
            <div class="col-md-6 text-right">
              <label>Receipeint Name:</label>
            </div>
            <div class="col-md-6">
              <span id="receipeintName">Saravana Kumar</span>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 text-right">
              <label>Movie Name:</label>
            </div>
            <div class="col-md-6">
              <span id="movieName">Kaithi</span>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 text-right">
              <label>Seat Class:</label>
            </div>
            <div class="col-md-6">
              <span id="classType">First Class</span>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 text-right">
              <label>Seat Numbers:</label>
            </div>
            <div class="col-md-6">
              <span id="seatNumbers">q</span>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 text-right">
              <label>No.of Seats:</label>
            </div>
            <div class="col-md-6">
              <span id="numbersofSeats">d</span>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 text-right">
              <label>Total Amount:</label>
            </div>
            <div class="col-md-6">
              <span id="amount">c</span>
            </div>
          </div>
          <div class="row text-center">
            <input type="submit" class="submit" onclick="previewConfirm()" id="confirmPreview" value="confirm">
          </div>
        </div>
        <div class="col-md-3"></div>
      </div>
    </form>
    <!-- payment form end -->
  </div>
  <!-- payment page end -->
</div>
<!-- main container end -->
<!-- scripting laguage start -->
  <script type="text/javascript">
  // page hiding action called at instance of loading page.At intially the page loading the payment container is hide by using the jquery function of .addClass
    var select_seat = localStorage.setitem;
    $(document).ready(function(){
        $("#payment").addClass("hide");
    });
  // end of payment page hiding jquery script
  // #jquery(page.addClass/removeClass) At the instance of clicking the submit button,This action triger the preview container to hide and payment container is visible by using the below jquery function
    $(document).ready(function(){
      $("#confirmPreview").click(function(){
        $("#confirmation").hide();
      });
      $("#confirmPreview").click(function(){
        $("#payment").removeClass("hide");
      });
    });
  // #jquery(page.addClass/removeClass) end
  // #javascript(preview_validation) The below scripting function trigerred by preview page form submit        (button.onclick methode). This function checking the input and redirecting next form
    function previewConfirm(){
      customer_name = document.getElementById("receipeintName").textContent;
      movie_name = document.getElementById("movieName").textContent;
      class_type = document.getElementById("classType").textContent;
      seat_numbers = document.getElementById("seatNumbers").textContent;
      numbers_of_seats = document.getElementById("numbersofSeats").textContent;
      amount = document.getElementById("amount").textContent;
    }
  // #javascript(preview_validation) end
  // #javascript function(validation of payment) The below function getting the all the input field and checking the inputs with creteria of card. The input is satisfying the creteria then redirecting the payment processing
    function paymentSubmission(){
      card_number = document.getElementById("cardNumber").value;
      card_holder = document.getElementById("cardHolder").value;
      expiry_month = document.getElementById("ExpiryMonth").value;
      expiry_year = document.getElementById("ExpiryYear").value;

      if(card_number.toString().length < 16){
        alert(card_number);
      }
      if(card_holder.toString().length >= 3){
        alert('success');
      }
      if(expiry_month >= 1 && expiry_month <= 12){
        alert('success');
      }
      if(expiry_year >= 2020 && expiry_year <= 2030){
        alert('success');
      }
      if((card_number.toString().length == 16) && (card_holder.length >= 3) && (expiry_month >= 1) && (expiry_month <= 12)
      && (expiry_year >= 2020) && (expiry_year <= 2030) ){
        alert('final success');
      }else{
        alert('final error');
      }
    }
  // #javascript function(validation of payment) end
  </script>
<!-- scripting language end -->
</body>
</html> 
