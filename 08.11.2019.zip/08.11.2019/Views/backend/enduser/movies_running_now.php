<?php include('headlinks.php'); ?>

<?php $movies = import();
// echo "<pre>";
// print_r($movies);
// echo "</pre>";
 ?>

<?php for($i=0;$i<count($movies);$i+=3) { ?>
			<div class="row">
				<?php for($j=$i;$j<=$i+2;$j+=1) { ?>
					<div class="col-md-4 movie-box text-center">
						<a href="/movie_name?<?php echo strtolower($movies[$j][2]) ?>">
							<img src="<?php echo $movies[$j][10]?>" class="box-image">
							<h3 class="text-left"><b><?php echo $movies[$j][2] ?></b></h3>
							<h6 class="text-center">Action</h6>
						</a>
					</div>
				<?php } ?>
			</div>
<?php } ?>
	













