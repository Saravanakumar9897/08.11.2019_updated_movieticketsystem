<?php include('headlinks.php'); ?>

<?php for($i=1;$i<=12;$i+=3) { ?>
			<div class="row">
				<?php for($j=$i;$j<=$i+2;$j+=1) { ?>
					<div class="col-md-4 movie-box">
						<img src="../Assets/backend/images/kaithi1.jpg" class="box-image">
						<h3 class="text-center"><b>KAITHI</b></h3>
						<h6 class="text-center">Action</h6>
					</div>
				<?php } ?>
			</div>
<?php } ?>
	


