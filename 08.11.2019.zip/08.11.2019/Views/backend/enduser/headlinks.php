<!-- Author:Saravana kumar.N
Description:Headlinks for the user ui interfaces
 -->
 <!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../../../Assets/backend/css/style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- library function including the head of the html page -->
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/style.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.css">
	<script type="text/javascript" src="../../../Assets/backend/seat_js/jquery.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.min.js"></script>


</head>
<body>
	<div class="container-fluid">