<!-- Author:Saravanakumar.N
Description:Displaying the Descsription of selected movie and show in theatres of that selected movie -->
<?php include('headlinks.php');?>
<?php 
$movies = import();
$uri = ($_SERVER['REQUEST_URI']);
$movie_uri = explode('?',$uri);
$movie_name = strtolower($movie_uri[1]);
foreach ($movies as $key => $value) {
	# code...
	if(strtolower($movies[$key][2])==$movie_name){
		$itr = $key;
		break;
	}

}


?>

<div class="row head_logo">
			<div class="col-md-4 text-left">
				<a href=""><img src="../../../Assets/backend/images/logoct.png" class="logo_head"></a>
			</div>
			<div class="col-md-4 input-group text-left">
				<input type="text" placeholder="Search Here...." class="search-bar rounded">
				<div class="input-group-append">
					<button class="btn btn-secondary" type="button">
						<i class="glyphicon glyphicon-search">Search</i>
					</button>
				</div>				
			</div>
			<div class="col-md-2">
			</div>
			<div class="col-md-2 text-center">
				<?php if($_SESSION['user']['role_name']=='customer'){?>
				<a href="/admin"><input type="Button" class="btn btn-log-in" value="Sign-Out"></a>
				<?php }else{ ?>
					<a href="/admin"><input type="Button" class="btn btn-log-in" value="Log-In/Sign-Up"></a>
				<?php } ?>
			</div>
</div>
<div class="row">
	<div class="col-md-12">
		<img src="<?php echo $movies[$itr][11] ?>" width="1350" height="450">
</div>
</div>
<div class="row container-fluid">
	<h1 id="movie_name" width="100%"><?php echo $movies[$itr][2] ?></h1><span></span>
	<h4>U/A Action</h4>
</div>
<hr>
<div class="row">
	<div class="col-md-12">
		<h4 class="text-center">DESCRIPTION</h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</p>
			<hr>
	</div>
</div>
<div class="row ">
	<div class="col-md-12">
		<h3 class="text-center">Select Your Show </h3>
	</div>
</div>
<form action="/seat_numbers">
<div class="row container-fluid">
	<div class="col-md-4">
	</div>
	<div class="col-md-4">
		<input type="date" class="show-date text-center" required>
	</div>
	<div class="col-md-4">
	</div>
</div>
<br/>

<div class="row">
	<div class="col-md-4 text-center">
		<h6 class="navbar-brand">Theatre_name-1</h6>
	</div>
	<div class="col-md-8">
		<input type="submit" value="show-1" class="btn btn-shows">
		<input type="submit" value="show-2" class="btn btn-shows">
		<input type="submit" value="show-3" class="btn btn-shows">
	</div>
</div>
<br>
<div class="row">
	<div class="col-md-4 text-center">
		<h6 class="navbar-brand">Theatre_name-2</h6>
	</div>
	<div class="col-md-8">
		<input type="submit" value="show-1" class="btn btn-shows">
		<input type="submit" value="show-2" class="btn btn-shows">
		<input type="submit" value="show-3" class="btn btn-shows">
	</div>
</div>
<br>
<div class="row">
	<div class="col-md-4 text-center">
		<h6 class="navbar-brand">Theatre_name-3</h6>
	</div>
	<div class="col-md-8">
		<input type="submit" value="show-1" class="btn btn-shows">
		<input type="submit" value="show-2" class="btn btn-shows">
		<input type="submit" value="show-3" class="btn btn-shows">
	</div>
</div>
</form>
<br>

<br>


<?php include('footlinks.php');?>

<script type="text/javascript">
	var movie_name = document.getElementById("movie_name").textContent;
	localStorage.setitem = movie_name;
</script>